/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.command_design_pattren;
import java.util.ArrayList;
public class RemotControll {
    private ArrayList<CommandConfic> commandConfic = new ArrayList<>();

    public RemotControll(CommandConfic commandConfic) {
       this.commandConfic.add(commandConfic);
    }
    public void setCommandConfic(CommandConfic commandConfic){
        this.commandConfic.add(commandConfic);
    }

    public  void onBUttonPress(int i ,String str){
        commandConfic.get(i).excecute(str);
    }

}

    

