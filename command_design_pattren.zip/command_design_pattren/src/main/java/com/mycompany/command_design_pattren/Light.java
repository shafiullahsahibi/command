/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.command_design_pattren;


public class Light implements IOT{
    
    
    public void on(){
        System.out.println("the light is on");
    }

    public void off(){
        System.out.println("the light is off!");
    }
}
    

