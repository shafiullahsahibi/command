/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.command_design_pattren;
public class Command_design_pattren {

    public static void main(String[] args) {
        Light light = new Light();
        Fan fan = new Fan();

        CommandConfic  commandConficLight = new CommandConfic(light);

      CommandConfic commandConficFan = new CommandConfic(fan);


        RemotControll remotControll = new RemotControll(commandConficFan);
        remotControll.setCommandConfic(commandConficLight);

     remotControll.onBUttonPress(1,"on");

    }
}
