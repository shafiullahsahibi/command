/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.command_design_pattren; 
public class CommandConfic extends Command{
private IOT iot;
    public CommandConfic(IOT light) {
        this.iot = light;
    }
    public void excecute(String str) {
        if (str.equals("on"))
        iot.on();
        else if (str.equals("off"))
            iot.off();
        else throw new RuntimeException("no command please write good command");
    }
}
    

